Hello from IMG_25522 !

This is a crazy project

creator: I am crazy! I am crazy! I am crazy! I am crazy! I am crazy! I am crazy!

All the files in this floder shouldn't be moved out or changed,or the program may not be able to run 
successfully

Probably start.txt will give you more information...